import registerRootComponent from 'expo/build/launch/registerRootComponent';

import Routes from './routes';

registerRootComponent(Routes);
